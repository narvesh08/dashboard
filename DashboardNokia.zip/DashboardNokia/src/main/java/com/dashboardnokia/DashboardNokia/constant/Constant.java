package com.dashboardnokia.DashboardNokia.constant;

public class Constant {

    public static final String REMOTE_HOST = "10.159.236.5";
    public static final String USERNAME = "ca_5gapbgl";
    public static final String PASSWORD = "Nokia1234";
    public static final int REMOTE_PORT = 22;
    public static final int SESSION_TIMEOUT = 10000;
    public static final int CHANNEL_TIMEOUT = 5000;

}
