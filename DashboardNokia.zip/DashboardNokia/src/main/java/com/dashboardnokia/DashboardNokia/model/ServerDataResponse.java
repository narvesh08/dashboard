package com.dashboardnokia.DashboardNokia.model;

import java.util.List;

public class ServerDataResponse {
    List<ServerData> data;

    public List<ServerData> getData() {
        return data;
    }

    public void setData(List<ServerData> data) {
        this.data = data;
    }
}
